package com.example.ivan.gitbrowser;

import android.view.View;

/**
 * Created by ivan on 22.12.17.
 *
 */

public interface ItemClickListener {
    void onItemClick(View view, int position);
}
